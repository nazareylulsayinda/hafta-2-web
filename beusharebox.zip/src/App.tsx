/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  Search, 
  Heart, 
  MessageSquare, 
  Trash2, 
  Moon, 
  Sun, 
  Filter, 
  Image as ImageIcon, 
  X, 
  ChevronDown, 
  BarChart3,
  Download,
  Upload,
  ExternalLink,
  Clock,
  Tag,
  TrendingUp,
  Loader2,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { io, Socket } from 'socket.io-client';
import { GoogleGenAI } from "@google/genai";

// --- Types ---

interface Comment {
  id: string;
  productId: string;
  text: string;
  createdAt: number;
}

interface Product {
  id: string;
  title: string;
  description: string;
  price: string;
  category: string;
  image: string | null;
  likes: number;
  comments: Comment[];
  createdAt: number;
}

type SortOption = 'newest' | 'price-asc' | 'price-desc' | 'likes';

// --- Constants ---

const CATEGORIES = ['Elektronik', 'Kitap', 'Giyim', 'Ev Eşyası', 'Diğer'];

// --- Components ---

export default function App() {
  // --- State ---
  const [products, setProducts] = useState<Product[]>([]);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Hepsi');
  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [toasts, setToasts] = useState<{ id: string; message: string; type: 'success' | 'error' }[]>([]);
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);

  // Form State
  const [newProduct, setNewProduct] = useState({
    title: '',
    description: '',
    price: '',
    category: CATEGORIES[0],
    image: null as string | null,
    imageUrl: ''
  });

  // --- Effects ---

  // Socket.io Setup
  useEffect(() => {
    const newSocket = io();
    setSocket(newSocket);

    newSocket.on('initial_data', (data: Product[]) => {
      setProducts(data);
    });

    newSocket.on('product_added', (product: Product) => {
      setProducts(prev => [product, ...prev]);
      addToast('Yeni bir ürün paylaşıldı!');
    });

    newSocket.on('product_deleted', (id: string) => {
      console.log('Client: Received product_deleted for ID:', id);
      setProducts(prev => prev.filter(p => p.id !== id));
      if (selectedProduct?.id === id) setSelectedProduct(null);
      addToast('Ürün başarıyla silindi.');
    });

    newSocket.on('product_liked', ({ id, likes }: { id: string, likes: number }) => {
      setProducts(prev => prev.map(p => p.id === id ? { ...p, likes } : p));
    });

    newSocket.on('comment_added', (comment: Comment) => {
      setProducts(prev => prev.map(p => 
        p.id === comment.productId ? { ...p, comments: [...p.comments, comment] } : p
      ));
    });

    return () => {
      newSocket.close();
    };
  }, []);

  // Theme effect
  useEffect(() => {
    const savedTheme = localStorage.getItem('beu_theme');
    if (savedTheme === 'dark') setIsDarkMode(true);
  }, []);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('beu_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('beu_theme', 'light');
    }
  }, [isDarkMode]);

  // --- Handlers ---

  const addToast = (message: string, type: 'success' | 'error' = 'success') => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3000);
  };

  const generateAIImage = async () => {
    if (!newProduct.title) {
      addToast('Görsel oluşturmak için önce bir başlık yazmalısınız.', 'error');
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      addToast('Gemini API anahtarı eksik.', 'error');
      return;
    }

    try {
      setIsGeneratingImage(true);
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `Create a high-quality, professional studio product photograph of "${newProduct.title}". ${newProduct.description ? `Context: ${newProduct.description}.` : ''} The image should be clean, well-lit, and centered, suitable for an e-commerce listing. No text in the image.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          imageConfig: {
            aspectRatio: "4:3"
          }
        }
      });

      let foundImage = false;
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          const base64Data = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          setNewProduct(prev => ({ ...prev, image: base64Data, imageUrl: '' }));
          addToast('Görsel başarıyla oluşturuldu!', 'success');
          foundImage = true;
          break;
        }
      }
      
      if (!foundImage) {
        addToast('Görsel oluşturulamadı, lütfen tekrar deneyin.', 'error');
      }
    } catch (error) {
      console.error('Image generation error:', error);
      addToast('Görsel oluşturulurken bir hata oluştu.', 'error');
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewProduct(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.title || !newProduct.price) {
      addToast('Lütfen başlık ve fiyat alanlarını doldurun.', 'error');
      return;
    }

    let finalImage = newProduct.image || newProduct.imageUrl;
    
    const product: Omit<Product, 'comments'> = {
      id: Math.random().toString(36).substr(2, 9),
      title: newProduct.title,
      description: newProduct.description,
      price: newProduct.price,
      category: newProduct.category,
      image: finalImage || `https://picsum.photos/seed/${Math.random()}/400/300`,
      likes: 0,
      createdAt: Date.now()
    };

    socket?.emit('add_product', product);
    setIsAddModalOpen(false);
    setNewProduct({ title: '', description: '', price: '', category: CATEGORIES[0], image: null, imageUrl: '' });
  };

  const handleDeleteProduct = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    console.log('Client: Delete button clicked for ID:', id);
    
    if (!socket) {
      console.error('Client: Socket is not connected!');
      addToast('Bağlantı hatası, lütfen sayfayı yenileyin.', 'error');
      return;
    }

    // Temporarily removing confirm to rule out environment issues
    socket.emit('delete_product', id);
    addToast('Ürün siliniyor...');
  };

  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    socket?.emit('like_product', id);
  };

  const handleAddComment = (productId: string, text: string) => {
    if (!text.trim()) return;
    const newComment: Comment = {
      id: Math.random().toString(36).substr(2, 9),
      productId,
      text,
      createdAt: Date.now()
    };
    socket?.emit('add_comment', newComment);
  };

  const exportData = () => {
    const dataStr = JSON.stringify(products, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = 'beusharebox_data.json';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    addToast('Veriler dışa aktarıldı.');
  };

  // --- Filtered & Sorted Products ---

  const filteredProducts = useMemo(() => {
    return products
      .filter(p => {
        const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                             p.description.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesCategory = selectedCategory === 'Hepsi' || p.category === selectedCategory;
        return matchesSearch && matchesCategory;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') return b.createdAt - a.createdAt;
        if (sortBy === 'price-asc') return parseFloat(a.price) - parseFloat(b.price);
        if (sortBy === 'price-desc') return parseFloat(b.price) - parseFloat(a.price);
        if (sortBy === 'likes') return b.likes - a.likes;
        return 0;
      });
  }, [products, searchQuery, selectedCategory, sortBy]);

  const stats = useMemo(() => ({
    total: products.length,
    likes: products.reduce((acc, p) => acc + p.likes, 0),
    comments: products.reduce((acc, p) => acc + p.comments.length, 0)
  }), [products]);

  // Sync selected product
  useEffect(() => {
    if (selectedProduct) {
      const updated = products.find(p => p.id === selectedProduct.id);
      if (updated) setSelectedProduct(updated);
    }
  }, [products]);

  // --- Render ---

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 transition-colors duration-300 font-sans">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-md border-b border-zinc-200 dark:border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
              <BarChart3 size={24} />
            </div>
            <h1 className="text-xl font-bold tracking-tight hidden sm:block">BEUShareBox</h1>
          </div>

          <div className="flex-1 max-w-md mx-4 relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 group-focus-within:text-emerald-500 transition-colors" size={18} />
            <input 
              type="search" 
              placeholder="Ürün ara..."
              className="w-full pl-10 pr-4 py-2 bg-zinc-100 dark:bg-zinc-800 border-none rounded-full focus:ring-2 focus:ring-emerald-500 transition-all outline-none text-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full transition-colors"
              title="Tema Değiştir"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button 
              onClick={exportData}
              className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full transition-colors hidden sm:flex"
              title="Verileri Dışa Aktar"
            >
              <Download size={20} />
            </button>
            <button 
              onClick={() => setIsAddModalOpen(true)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-full flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-all active:scale-95"
            >
              <Plus size={20} />
              <span className="hidden sm:inline font-medium">Paylaş</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats & Filters */}
        <section className="mb-8 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center gap-4 shadow-sm">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl flex items-center justify-center">
                <Tag size={24} />
              </div>
              <div>
                <p className="text-xs text-zinc-500 uppercase font-semibold tracking-wider">Toplam Ürün</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
            </div>
            <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center gap-4 shadow-sm">
              <div className="w-12 h-12 bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 rounded-xl flex items-center justify-center">
                <Heart size={24} />
              </div>
              <div>
                <p className="text-xs text-zinc-500 uppercase font-semibold tracking-wider">Toplam Beğeni</p>
                <p className="text-2xl font-bold">{stats.likes}</p>
              </div>
            </div>
            <div className="bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center gap-4 shadow-sm">
              <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center">
                <MessageSquare size={24} />
              </div>
              <div>
                <p className="text-xs text-zinc-500 uppercase font-semibold tracking-wider">Yorum Sayısı</p>
                <p className="text-2xl font-bold">{stats.comments}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 w-full sm:w-auto no-scrollbar">
              <Filter size={18} className="text-zinc-400 flex-shrink-0" />
              {['Hepsi', ...CATEGORIES].map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                    selectedCategory === cat 
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20' 
                      : 'bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 hover:border-emerald-500'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <TrendingUp size={18} className="text-zinc-400" />
              <select 
                className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg px-3 py-1.5 text-sm outline-none focus:ring-2 focus:ring-emerald-500 w-full sm:w-auto"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
              >
                <option value="newest">En Yeni</option>
                <option value="price-asc">Fiyat (Artan)</option>
                <option value="price-desc">Fiyat (Azalan)</option>
                <option value="likes">En Çok Beğenilen</option>
              </select>
            </div>
          </div>
        </section>

        {/* Product Grid */}
        <section>
          {filteredProducts.length === 0 ? (
            <div className="text-center py-20 bg-white dark:bg-zinc-900 rounded-3xl border border-dashed border-zinc-300 dark:border-zinc-700">
              <div className="w-20 h-20 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-4 text-zinc-400">
                <ImageIcon size={40} />
              </div>
              <h3 className="text-lg font-semibold mb-2">Henüz ürün yok</h3>
              <p className="text-zinc-500 max-w-xs mx-auto">İlk paylaşımı sen yap! "Paylaş" butonuna basarak ürün ekleyebilirsin.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              <AnimatePresence mode="popLayout">
                {filteredProducts.map(product => (
                  <motion.article
                    key={product.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    onClick={() => setSelectedProduct(product)}
                    className="group bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer relative"
                  >
                    <div className="aspect-[4/3] overflow-hidden relative">
                      <img 
                        src={product.image || ''} 
                        alt={product.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-3 left-3">
                        <span className="bg-black/50 backdrop-blur-md text-white text-[10px] font-bold px-2 py-1 rounded-md uppercase tracking-wider">
                          {product.category}
                        </span>
                      </div>
                      <button 
                        type="button"
                        onClick={(e) => handleDeleteProduct(product.id, e)}
                        className="absolute top-3 right-3 p-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-full shadow-lg transition-all z-50 active:scale-90"
                        title="Ürünü Sil"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                    
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-lg leading-tight line-clamp-1">{product.title}</h3>
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold">₺{product.price}</span>
                      </div>
                      <p className="text-zinc-500 dark:text-zinc-400 text-sm line-clamp-2 mb-4 h-10">
                        {product.description}
                      </p>
                      
                      <div className="flex items-center justify-between pt-4 border-t border-zinc-100 dark:border-zinc-800">
                        <div className="flex items-center gap-4">
                          <button 
                            onClick={(e) => handleLike(product.id, e)}
                            className="flex items-center gap-1.5 text-zinc-500 hover:text-rose-500 transition-colors"
                          >
                            <Heart size={18} className={product.likes > 0 ? 'fill-rose-500 text-rose-500' : ''} />
                            <span className="text-xs font-semibold">{product.likes}</span>
                          </button>
                          <div className="flex items-center gap-1.5 text-zinc-500">
                            <MessageSquare size={18} />
                            <span className="text-xs font-semibold">{product.comments.length}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 text-[10px] text-zinc-400 uppercase font-bold">
                          <Clock size={12} />
                          {new Date(product.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </motion.article>
                ))}
              </AnimatePresence>
            </div>
          )}
        </section>
      </main>

      {/* Add Product Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white dark:bg-zinc-900 w-full max-w-md rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-5 border-b border-zinc-100 dark:border-zinc-800 flex justify-between items-center">
                <h2 className="text-lg font-bold">Yeni Ürün Paylaş</h2>
                <button onClick={() => setIsAddModalOpen(false)} className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full">
                  <X size={18} />
                </button>
              </div>
              
              <form onSubmit={handleAddProduct} className="p-5 space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Ürün Görseli (URL veya Dosya)</label>
                  
                  <div className="flex gap-2">
                    <input 
                      type="url" 
                      className="flex-1 bg-zinc-100 dark:bg-zinc-800 border-none rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                      placeholder="Görsel URL'si yapıştırın..."
                      value={newProduct.imageUrl}
                      onChange={e => {
                        const url = e.target.value;
                        setNewProduct(prev => ({ ...prev, imageUrl: url, image: null, price: url }));
                      }}
                    />
                    <button
                      type="button"
                      onClick={generateAIImage}
                      disabled={isGeneratingImage || !newProduct.title}
                      className="bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400 text-white px-3 rounded-xl transition-colors flex items-center gap-1 text-xs font-bold whitespace-nowrap"
                      title="Yapay Zeka ile Oluştur"
                    >
                      {isGeneratingImage ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                      AI Oluştur
                    </button>
                  </div>

                  <div className="relative h-32 bg-zinc-100 dark:bg-zinc-800 rounded-2xl border-2 border-dashed border-zinc-300 dark:border-zinc-700 flex flex-col items-center justify-center gap-1 overflow-hidden group">
                    {newProduct.image || newProduct.imageUrl ? (
                      <>
                        <img 
                          src={newProduct.image || newProduct.imageUrl} 
                          className="w-full h-full object-cover" 
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://picsum.photos/seed/error/400/300?blur=2';
                          }}
                        />
                        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button 
                            type="button"
                            onClick={() => setNewProduct(prev => ({ ...prev, image: null, imageUrl: '' }))}
                            className="p-2 bg-rose-600 text-white rounded-full shadow-lg transform hover:scale-110 transition-transform"
                            title="Görseli Kaldır"
                          >
                            <X size={16} />
                          </button>
                        </div>
                      </>
                    ) : (
                      <>
                        <ImageIcon size={24} className="text-zinc-400" />
                        <p className="text-xs text-zinc-500">Dosya yükle veya sürükle</p>
                        <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                      </>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1 col-span-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Başlık</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-zinc-100 dark:bg-zinc-800 border-none rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-emerald-500"
                      placeholder="Örn: Kablosuz Kulaklık"
                      value={newProduct.title}
                      onChange={e => setNewProduct(prev => ({ ...prev, title: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Fiyat (₺)</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-zinc-100 dark:bg-zinc-800 border-none rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-emerald-500"
                      placeholder="0.00"
                      value={newProduct.price}
                      onChange={e => setNewProduct(prev => ({ ...prev, price: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Kategori</label>
                    <div className="relative">
                      <select 
                        className="w-full bg-zinc-100 dark:bg-zinc-800 border-none rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-emerald-500 appearance-none"
                        value={newProduct.category}
                        onChange={e => setNewProduct(prev => ({ ...prev, category: e.target.value }))}
                      >
                        {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                      <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" size={16} />
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Açıklama</label>
                  <textarea 
                    rows={3}
                    className="w-full bg-zinc-100 dark:bg-zinc-800 border-none rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                    placeholder="Ürün hakkında detaylı bilgi verin..."
                    value={newProduct.description}
                    onChange={e => setNewProduct(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>

                <button 
                  type="submit"
                  disabled={isGeneratingImage}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white font-bold py-3 rounded-xl shadow-lg shadow-emerald-500/20 transition-all active:scale-95 flex items-center justify-center gap-2"
                >
                  {isGeneratingImage ? (
                    <>
                      <Loader2 className="animate-spin" size={20} />
                      Görsel Oluşturuluyor...
                    </>
                  ) : (
                    <>
                      {(!newProduct.image && !newProduct.imageUrl) && <Sparkles size={18} />}
                      Ürünü Paylaş
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Product Detail Modal */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProduct(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="relative bg-white dark:bg-zinc-900 w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row max-h-[90vh]"
            >
              <button 
                onClick={() => setSelectedProduct(null)} 
                className="absolute top-4 right-4 z-10 p-2 bg-black/20 hover:bg-black/40 text-white rounded-full backdrop-blur-md"
              >
                <X size={20} />
              </button>

              <div className="md:w-1/2 bg-zinc-100 dark:bg-zinc-800">
                <img 
                  src={selectedProduct.image || ''} 
                  alt={selectedProduct.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="md:w-1/2 p-8 flex flex-col overflow-y-auto">
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider">
                      {selectedProduct.category}
                    </span>
                    <span className="text-[10px] text-zinc-400 uppercase font-bold">
                      {new Date(selectedProduct.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <h2 className="text-3xl font-bold mb-2">{selectedProduct.title}</h2>
                  <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mb-4">₺{selectedProduct.price}</p>
                  <p className="text-zinc-600 dark:text-zinc-400 leading-relaxed">
                    {selectedProduct.description}
                  </p>
                </div>

                <div className="flex items-center gap-6 mb-8 py-4 border-y border-zinc-100 dark:border-zinc-800">
                  <button 
                    onClick={(e) => handleLike(selectedProduct.id, e)}
                    className="flex items-center gap-2 text-zinc-600 dark:text-zinc-300 hover:text-rose-500 transition-colors"
                  >
                    <Heart size={24} className={selectedProduct.likes > 0 ? 'fill-rose-500 text-rose-500' : ''} />
                    <span className="font-bold">{selectedProduct.likes} Beğeni</span>
                  </button>
                  <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-300">
                    <MessageSquare size={24} />
                    <span className="font-bold">{selectedProduct.comments.length} Yorum</span>
                  </div>
                </div>

                <div className="flex-1">
                  <h3 className="font-bold mb-4 flex items-center gap-2">
                    Yorumlar
                  </h3>
                  <div className="space-y-4 mb-6">
                    {selectedProduct.comments.length === 0 ? (
                      <p className="text-sm text-zinc-500 italic">Henüz yorum yok. İlk yorumu sen yap!</p>
                    ) : (
                      selectedProduct.comments.map(comment => (
                        <div key={comment.id} className="bg-zinc-50 dark:bg-zinc-800/50 p-3 rounded-xl border border-zinc-100 dark:border-zinc-800">
                          <p className="text-sm">{comment.text}</p>
                          <p className="text-[10px] text-zinc-400 mt-1 font-bold uppercase">
                            {new Date(comment.createdAt).toLocaleTimeString()}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="mt-auto pt-4">
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="Yorum yaz..."
                      className="w-full bg-zinc-100 dark:bg-zinc-800 border-none rounded-full px-5 py-3 pr-12 outline-none focus:ring-2 focus:ring-emerald-500"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleAddComment(selectedProduct.id, e.currentTarget.value);
                          e.currentTarget.value = '';
                        }
                      }}
                    />
                    <button 
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 rounded-full transition-colors"
                      onClick={(e) => {
                        const input = e.currentTarget.previousSibling as HTMLInputElement;
                        handleAddComment(selectedProduct.id, input.value);
                        input.value = '';
                      }}
                    >
                      <Plus size={20} />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toasts */}
      <div className="fixed bottom-6 right-6 z-[100] flex flex-col gap-2">
        <AnimatePresence>
          {toasts.map(toast => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              className={`px-4 py-3 rounded-xl shadow-xl flex items-center gap-3 border ${
                toast.type === 'success' 
                  ? 'bg-emerald-500 text-white border-emerald-400' 
                  : 'bg-rose-500 text-white border-rose-400'
              }`}
            >
              {toast.type === 'success' ? <BarChart3 size={18} /> : <X size={18} />}
              <span className="text-sm font-bold">{toast.message}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <footer className="bg-white dark:bg-zinc-900 border-t border-zinc-200 dark:border-zinc-800 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white">
                <BarChart3 size={18} />
              </div>
              <span className="text-lg font-bold">BEUShareBox</span>
            </div>
            
            <div className="flex items-center gap-8 text-sm text-zinc-500 font-medium">
              <a href="#" className="hover:text-emerald-500 transition-colors">Hakkımızda</a>
              <a href="#" className="hover:text-emerald-500 transition-colors">Yardım</a>
              <a href="#" className="hover:text-emerald-500 transition-colors">Gizlilik</a>
              <a href="#" className="hover:text-emerald-500 transition-colors">İletişim</a>
            </div>

            <div className="flex items-center gap-4">
              <button className="p-2 bg-zinc-100 dark:bg-zinc-800 rounded-full hover:text-emerald-500 transition-colors">
                <ExternalLink size={18} />
              </button>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-zinc-100 dark:border-zinc-800 text-center text-xs text-zinc-400 font-bold uppercase tracking-widest">
            © 2026 BEUShareBox • Bitlis Eren Üniversitesi Web Tabanlı Programlama Projesi
          </div>
        </div>
      </footer>
    </div>
  );
}
