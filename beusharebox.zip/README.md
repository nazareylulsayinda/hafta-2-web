# BEUShareBox 🚀

BEUShareBox, kullanıcıların ürün paylaşabildiği, beğenebildiği ve yorum yapabildiği, eş zamanlı (real-time) çalışan ve yapay zeka destekli modern bir sosyal ticaret platformudur.

![BEUShareBox Preview](https://picsum.photos/seed/beushare/1200/600)

## ✨ Özellikler

- **Eş Zamanlı Güncellemeler:** Socket.io entegrasyonu sayesinde ürün ekleme, beğenme ve yorum yapma işlemleri tüm kullanıcılarda anında görünür.
- **Yapay Zeka Destekli Görsel Oluşturma:** Ürün başlığına ve açıklamasına uygun profesyonel görselleri Google Gemini AI (`gemini-2.5-flash-image`) kullanarak saniyeler içinde oluşturur.
- **Kalıcı Veri Depolama:** SQLite veritabanı sayesinde tüm paylaşımlar ve etkileşimler güvenli bir şekilde saklanır.
- **Modern ve Duyarlı Arayüz:** Tailwind CSS ve Framer Motion ile akıcı animasyonlara sahip, mobil uyumlu bir tasarım.
- **Karanlık Mod Desteği:** Göz yormayan karanlık mod ve şık aydınlık mod seçenekleri.
- **Gelişmiş Filtreleme:** Kategoriye göre filtreleme ve fiyata/tarihe göre sıralama seçenekleri.

## 🛠️ Teknolojiler

- **Frontend:** React, TypeScript, Tailwind CSS, Framer Motion, Lucide Icons
- **Backend:** Node.js, Express, Socket.io
- **Veritabanı:** Better-SQLite3
- **Yapay Zeka:** Google Gemini API (@google/genai)

## 🚀 Kurulum

Projeyi yerel makinenizde çalıştırmak için aşağıdaki adımları izleyin:

1. **Depoyu klonlayın:**
   ```bash
   git clone https://github.com/kullaniciadi/beusharebox.git
   cd beusharebox
   ```

2. **Bağımlılıkları yükleyin:**
   ```bash
   npm install
   ```

3. **Çevresel değişkenleri ayarlayın:**
   `.env` dosyası oluşturun ve Gemini API anahtarınızı ekleyin:
   ```env
   GEMINI_API_KEY=your_api_key_here
   ```

4. **Uygulamayı başlatın:**
   ```bash
   npm run dev
   ```
   Uygulama varsayılan olarak `http://localhost:3000` adresinde çalışacaktır.

## 📸 Ekran Görüntüleri

| Ana Sayfa | Ürün Paylaşma (AI Destekli) |
|-----------|----------------------------|
| ![Home](https://picsum.photos/seed/home/400/300) | ![Share](https://picsum.photos/seed/share/400/300) |

## 📄 Lisans

Bu proje MIT lisansı altında lisanslanmıştır. Daha fazla bilgi için `LICENSE` dosyasına bakınız.

---

Geliştiren: [Sizin Adınız]
