import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database('beusharebox.db');
db.pragma('foreign_keys = ON');

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    title TEXT,
    description TEXT,
    price TEXT,
    category TEXT,
    image TEXT,
    likes INTEGER DEFAULT 0,
    createdAt INTEGER
  );
  CREATE TABLE IF NOT EXISTS comments (
    id TEXT PRIMARY KEY,
    productId TEXT,
    text TEXT,
    createdAt INTEGER,
    FOREIGN KEY(productId) REFERENCES products(id) ON DELETE CASCADE
  );
`);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const PORT = 3000;

  app.use(express.json());

  // Socket.io logic
  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    // Send initial data
    const products = db.prepare('SELECT * FROM products ORDER BY createdAt DESC').all();
    const productsWithComments = products.map((p: any) => {
      const comments = db.prepare('SELECT * FROM comments WHERE productId = ? ORDER BY createdAt ASC').all(p.id);
      return { ...p, comments };
    });
    socket.emit('initial_data', productsWithComments);

    socket.on('add_product', (product) => {
      try {
        const stmt = db.prepare('INSERT INTO products (id, title, description, price, category, image, likes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        stmt.run(product.id, product.title, product.description, product.price, product.category, product.image, product.likes, product.createdAt);
        io.emit('product_added', { ...product, comments: [] });
      } catch (error) {
        console.error('Error adding product:', error);
      }
    });

    socket.on('delete_product', (id) => {
      console.log('Server: Received delete_product for ID:', id);
      try {
        // Manually delete comments first as a safety measure
        db.prepare('DELETE FROM comments WHERE productId = ?').run(id);
        const result = db.prepare('DELETE FROM products WHERE id = ?').run(id);
        console.log('Server: Delete result:', result);
        io.emit('product_deleted', id);
      } catch (error) {
        console.error('Server: Error deleting product:', error);
      }
    });

    socket.on('like_product', (id) => {
      try {
        db.prepare('UPDATE products SET likes = likes + 1 WHERE id = ?').run(id);
        const product = db.prepare('SELECT likes FROM products WHERE id = ?').get(id) as any;
        io.emit('product_liked', { id, likes: product.likes });
      } catch (error) {
        console.error('Error liking product:', error);
      }
    });

    socket.on('add_comment', (comment) => {
      try {
        const stmt = db.prepare('INSERT INTO comments (id, productId, text, createdAt) VALUES (?, ?, ?, ?)');
        stmt.run(comment.id, comment.productId, comment.text, comment.createdAt);
        io.emit('comment_added', comment);
      } catch (error) {
        console.error('Error adding comment:', error);
      }
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
